import * as React from 'react';
import { View, SafeAreaView, StyleSheet, Linking, ScrollView, Text} from 'react-native';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { NavigationContainer } from '@react-navigation/native';
import { Card,Button } from 'react-native-elements';
import NoticiasScreen from './Screens/FunctionNoticias'

const Drawer = createDrawerNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Drawer.Navigator initialRouteName="Noticias">
        <Drawer.Screen name="Noticias" component={NoticiasScreen} />
      </Drawer.Navigator>
    </NavigationContainer>
  );
}
