import * as React from 'react';
import { View, SafeAreaView, StyleSheet, Linking, ScrollView, Text} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { Card } from 'react-native-elements';


function NoticiasScreen({ navigation }) {
  return (
    <ScrollView>
    
      <Card>
        <Card.Title h4>Milho: B3 sobe nesta 6ªfeira e acumula pequenos ganhos na semana</Card.Title>
            <View >
              A sexta-feira (19) chega ao final com os preços futuros do milho sustentando movimentações positivas na Bolsa                     Brasileira (B3), e acumulando pequenas altas semanais.
              O vencimento janeiro...
           </View>
      </Card>   

    </ScrollView>
  );
}
export default NoticiasScreen;
