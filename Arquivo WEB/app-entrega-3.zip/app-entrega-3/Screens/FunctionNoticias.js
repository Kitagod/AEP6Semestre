import * as React from 'react';
import { View, SafeAreaView, StyleSheet, Linking, ScrollView, Text} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { Card,Button } from 'react-native-elements';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 0,
    backgroundColor: '#ecf0f1',
  },
  paragraph: {
    margin: 20,
    fontSize: 15,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#34495e',
  },
});


function NoticiasScreen({ navigation }) {
  return (
    <ScrollView>
      
      <Card>
        <Card.Title h4>Milho: B3 sobe nesta 6ªfeira e acumula pequenos ganhos na semana</Card.Title>
          <SafeAreaView style={styles.container}>
            <View style={styles.paragraph}>
              A sexta-feira (19) chega ao final com os preços futuros do milho sustentando movimentações positivas na Bolsa                     Brasileira (B3), e acumulando pequenas altas semanais.
              O vencimento janeiro...
           </View>
            <Text
              style={styles.hyperlinkStyle} 
              onPress={() => {
                Linking.openURL('https://www.noticiasagricolas.com.br/noticias/milho/                                                             302945-milho-b-3-sobe-nesta-6-feira-e-acumula-pequenos-ganhos-na-semana.html#.YZgh37pv-Uk');}}>
              <h6>click aqui para ver a noticia completa</h6> 
            </Text >
          </SafeAreaView>
      </Card>

      <Card>
        <Card.Title h4>Petróleo desaba 3% e pressiona açúcar em NY e Londres nesta 6ª feira</Card.Title>
          <SafeAreaView style={styles.container}>
            <View style={styles.paragraph}>
              As cotações futuras do açúcar encerraram a sessão desta sexta-feira (19) com perdas moderadas nas bolsas de Nova                  York e Londres. O mercado repercutiu a baixa expressiva do petróleo no internacional, câmbio...
            </View>
            <Text
              style={styles.hyperlinkStyle} 
              onPress={() => {
                Linking.openURL('https://www.noticiasagricolas.com.br/noticias/sucroenergetico/                                                   302924-petroleo-desaba-3-e-pressiona-acucar-em-ny-e-londres-nesta-6-feira.html#.YZgsybpv-Un');}}>
              <h6>click aqui para ver a noticia completa</h6> 
            </Text >
          </SafeAreaView>
      </Card>

      <Card>
        <Card.Title h3>Noticias exemplo</Card.Title>
          <SafeAreaView style={styles.container}>
            <View style={styles.paragraph}>
              Noticia exemplo
            </View>
            <Text
              style={styles.hyperlinkStyle} 
              onPress={() => {
                Linking.openURL('https://www.youtube.com/watch?v=dQw4w9WgXcQ');}}>
              <h6>click aqui para ver a noticia completa</h6> 
            </Text >
          </SafeAreaView>
      </Card>
      
    </ScrollView>
  );
}
export default NoticiasScreen;
