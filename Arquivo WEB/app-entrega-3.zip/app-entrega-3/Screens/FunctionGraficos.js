import * as React from 'react';
import { View, SafeAreaView, StyleSheet, Linking, ScrollView, Text} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { Card,Button } from 'react-native-elements';

const styles = StyleSheet.create({
});

function GraficosScreen({ navigation }) {
  return (
    <ScrollView>
      <Card>
        <Card.Title h4>Gráficos de Valores de Fechamento da Soja Jan 2022</Card.Title>
          <SafeAreaView>
            <Text
              style={styles.hyperlinkStyle} 
              onPress={() => {
                Linking.openURL('https://www.tradingview.com/symbols/CBOT-ZSF2022/?utm_source=www.noticiasagricolas.com.br&                       utm_medium=widget_new&utm_campaign=chart&utm_term=CBOT%3AZSF2022');}}>
              <h6>click para ver o gráficos completo</h6> 
            </Text >
          </SafeAreaView>
      </Card>
    </ScrollView>
  );
}

export default GraficosScreen;
